#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("hello, world\n");
    string s = GetString();
    printf("hello, %s\n", s);
}