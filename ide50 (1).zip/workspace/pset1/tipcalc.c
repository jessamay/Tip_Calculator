#include <cs50.h>
#include <stdio.h>

float MealPrice();
float TipSelect();
int BillSplit();

int main(void)
{
    printf("Welcome to the tip calculator!\n");
    
    // ask user for pre-tip total
    float m = MealPrice();
    
    // ask user to tip percentage
    float n = TipSelect();
    
    // display tip amount
    float a = m * 0.01 * n;
    printf("Tip amount: $%.02f\n", a);
    
    // display total bill
    float t = m + n * 0.01 * m;
    printf("Total bill: $%.02f\n", t);
}

/**
 * Only allows positive price for meal
 */
float MealPrice(void)
{
    float m;
    do
    {
        printf("Price of meal, pre-tip: $");
        m = GetFloat();
    }
    while (m < 0);
    return m; 
}

/**
 * Only allows tip percentages of 15-20
 */
float TipSelect(void)
{
    float n;
    do
    {
        printf("Provide a tip percentage: ");
        n = GetFloat();
    }
    while (n < 15 || n > 20);
    return n;
}