#include <stdio.h>
#include <cs50.h>

int main(void)
{
  // ask user for length of shower in minutes
  printf("Length of shower in minutes: ");
  int i = GetInt();
  
  // multiply number of minutes by 12 
  int b =  i * 12;
  
  // display result in number of water bottles
  printf("Bottles of water: %i\n", b);
}