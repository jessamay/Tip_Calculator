#include <cs50.h>
#include <stdio.h>

int GetPositiveInt();

int main(void)
{
    // ask user for non-negative integer no greater than 23
    int n = GetPositiveInt();

    // recreate half-pyramid using hashes
    for (int i = 0; i < n; i++)
    {
        // print spaces
        for (int s = 0; s < n - 1 - i; s++)
        {
        printf("%s", " ");
        }
        
        // print hashes
        for (int h = 0; h < i + 2; h++)
        {
            printf("#");
        }
        
        // print new line
        printf("\n");
    }
}

/**
 * Gets a positive integer from a user
 */
int GetPositiveInt(void)
{
    int n;
    do
    {
        printf("Height: ");
        n = GetInt();
        
    }
    while (n < 0 || n > 23);
    return n; 
}
